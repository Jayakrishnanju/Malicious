from __future__ import absolute_import

from .cloudpickle import *

__version__ = '0.8.0'
